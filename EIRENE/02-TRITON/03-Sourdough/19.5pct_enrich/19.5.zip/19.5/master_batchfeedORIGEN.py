#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  9 15:30:37 2024

@author: c55
"""

###############################################################################
#
#              EIRENE Continuous Refueling Alternate Approach
#
#     By: C. Erika Moss
#
#     Description: This approach is similar to the batch refueling approach,
#                  except depletion is performed for a very small timestep
#                  to simulate continuous refueling. No critical refuel search
#                  is performed, with the desired refueling rate instead being
#                  defined at the start of the simulation. This refueling rate
#                  remains constant throughout the entire depletion.
#
#     NOTE: This updated version includes ORIGEN.
#
###############################################################################

import time
import os
import shutil
import salts_wf
#import initialize_BOC
#from initialize_BOC import BOC_core
import numpy as np
from numpy import genfromtxt
#import matplotlib.pyplot as plt
import math
import sys, re
import subprocess
import batchfeed_ORIGEN
from batchfeed_ORIGEN import EIRENE_Deck

if __name__ == '__main__':
    print("This master script runs a full sourdough depletion simulation for EIRENE.")
    input("Press Ctrl+C to quit, or enter else to test it.")

    ##################################################################
    #        Initialize the BOC Core and Run the TRITON Deck
    ##################################################################

#    boc = BOC_core()
#    print("Writing BOC EIRENE TRITON deck...")
#    boc.save_deck()
#    boc.write_sub_shell()
#    boc.add_shell_permission()
#    print("Running TRITON deck...")
#    boc.run_SCALE()

    ###################################################################
    #                  Cycle Through Depletion Steps 
    ###################################################################

    decks = EIRENE_Deck()
    iter = np.arange(301, 766, 1)        # Depletion steps
    for i in iter:
        decks.write_KENO_decks(i)
        decks.write_conv_data(i)
        decks.add_shell_permission_cd(i)
#        print("Extracting k-eff data for depletion step {}...".format(i))
        decks.convert_data(i)
#        print("***** Writing TRITON deck...")
        decks.write_new_TRITON_deck(i)
        decks.write_qsub_file(i)
        decks.run_SCALE(i)
        print("Running TRITON deck...")

      # ----- Check to see if TRITON is finished running. Wait for it to finish if not. -----

        main_path = os.path.expanduser('~/EIRENE13/19.5/dep_step_{}'.format(i))
        os.chdir(main_path)
        check = False       # Initialize check
        while check == False:
          if os.path.exists('./EIRENE.f71'):
            check = True
            break
          else:                 
              check = False
              print("The atoms are still working; please stand by...")
              time.sleep(10.0)

    print("*******************************************")
    print("All done! The atoms are very happy now :D")
    print("*******************************************")
