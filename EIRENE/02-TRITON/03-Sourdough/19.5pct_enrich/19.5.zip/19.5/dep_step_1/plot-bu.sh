
#!/bin/bash

cat EIRENE.out  | awk '/best est/{print $6" "$10}' > _dat_keff
cat EIRENE.out  | awk '/Transport k=/{print $3" "$6" "$10" "$14}' > _dat_bu
paste _dat_bu _dat_keff > dep-data.out
rm _dat_keff _dat_bu
    